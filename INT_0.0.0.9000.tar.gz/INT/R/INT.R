#' Inverse Normal Transformation
#'
#' @param r is a vector of the ranks of the samples (from 1 to n).
#' @param n is the number of the samples.
#' @param k is an offset to ensure that all fractional ranks are strictly between zero and one.
#' @details Perform a rank-based inverse normal transformation.
#' @return The vector of the transformed data (Z-scores).

INT_function = function(r, n, k) {
  output = 0
  for (i in 1:n) {
    output[i] = probitlink((r[i] - k)/(n + 1 - 2*k))
  }
  return(output)
}
